import UserCard from "../components/UserCard";
import { User } from "../types/User";

const UserDetailPage: React.FC = () => {
  return <div></div>;
};

export default UserDetailPage;
