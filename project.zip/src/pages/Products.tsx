const ProductsPage: React.FC = () => {
  return <h1>ProductsPage</h1>;
};

export default ProductsPage;
