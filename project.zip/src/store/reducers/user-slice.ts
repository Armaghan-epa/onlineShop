import { createSlice } from "@reduxjs/toolkit";
import { getUser } from "../../API/user";

export const userSlice = createSlice({
  name: "user",
  initialState: {
    userData: {},
  },
  reducers: {
    setUserData(state, action) {
      state.userData = action.payload;
    },
  },
});

export const { setUserData } = userSlice.actions;

//export reducer
export default userSlice.reducer;

//create thunk to fetch user data
export const fetchUserData = () => async (dispatch: any) => {
  try {
    const response = await fetch("https://fakestoreapi.com/users/1");
    const data = await response.json();
    dispatch(setUserData(data));
  } catch (err) {
    console.error(err);
  }
};
export const userReducer = userSlice.reducer;
