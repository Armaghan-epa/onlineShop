import React from "react";
import axios from "axios";
import { Provider, useDispatch } from "react-redux";
import store from "./store/store";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import Router from "./components/MyRouter";
import "./App.css";
import { setUserData } from "./store/reducers/user-slice";
import { getUser } from "./API/user";

function App() {
  // const [user, setUser] = React.useState<User | null>(null);
  const dispatch = useDispatch();

  // React.useEffect(() => {
  //   // const fetchData = async () => {
  //   //   const result = await axios("https://fakestoreapi.com/users/1");
  //   //   return result.data;
  //   // };
  //   dispatch(setUserData());
  // }, []);
  // return <h1 className="text-3xl font-bold underline text-center">{user}</h1>;
  // return <RouterProvider router={router} />;

  return <RouterProvider router={Router}></RouterProvider>;
}

export default App;
