import axios from "axios";

export const getUser = async () => {
  return await axios("https://fakestoreapi.com/users/1");
};
